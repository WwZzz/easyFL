import os.path
import torch
import torch.nn
from torch.utils.data import Dataset, ConcatDataset
from typing import List
import numpy as np
from pandas.tseries import offsets
from pandas.tseries.frequencies import to_offset
import pandas as pd

def time_features(dates, timeenc=1, freq='h'):
    """
    > `time_features` takes in a `dates` dataframe with a 'dates' column and extracts the date down to `freq` where freq can be any of the following if `timeenc` is 0:
    > * m - [month]
    > * w - [month]
    > * d - [month, day, weekday]
    > * b - [month, day, weekday]
    > * h - [month, day, weekday, hour]
    > * t - [month, day, weekday, hour, *minute]
    >
    > If `timeenc` is 1, a similar, but different list of `freq` values are supported (all encoded between [-0.5 and 0.5]):
    > * Q - [month]
    > * M - [month]
    > * W - [Day of month, week of year]
    > * D - [Day of week, day of month, day of year]
    > * B - [Day of week, day of month, day of year]
    > * H - [Hour of day, day of week, day of month, day of year]
    > * T - [Minute of hour*, hour of day, day of week, day of month, day of year]
    > * S - [Second of minute, minute of hour, hour of day, day of week, day of month, day of year]

    *minute returns a number from 0-3 corresponding to the 15 minute period it falls into.
    """
    if timeenc==0:
        dates['month'] = dates.date.apply(lambda row:row.month,1)
        dates['day'] = dates.date.apply(lambda row:row.day,1)
        dates['weekday'] = dates.date.apply(lambda row:row.weekday(),1)
        dates['hour'] = dates.date.apply(lambda row:row.hour,1)
        dates['minute'] = dates.date.apply(lambda row:row.minute,1)
        dates['minute'] = dates.minute.map(lambda x:x//15)
        freq_map = {
            'y':[],'m':['month'],'w':['month'],'d':['month','day','weekday'],
            'b':['month','day','weekday'],'h':['month','day','weekday','hour'],
            't':['month','day','weekday','hour','minute'],
        }
        return dates[freq_map[freq.lower()]].values
    if timeenc==1:
        dates = pd.to_datetime(dates.date.values)
        return np.vstack([feat(dates) for feat in time_features_from_frequency_str(freq)]).transpose(1,0)

class StandardScaler():
    def __init__(self):
        self.mean = 0.
        self.std = 1.

    def fit(self, data):
        self.mean = data.mean(0)
        self.std = data.std(0)

    def transform(self, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data - mean) / std

    def inverse_transform(self, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        if data.shape[-1] != mean.shape[-1]:
            mean = mean[-1:]
            std = std[-1:]
        return (data * std) + mean

class IndividualDataset(Dataset):
    def __init__(self, x, y, lenx:int, leny:int, time=None, name=None, overlap=0):
        self.x = x
        self.y = y
        self.time = time
        self.name = name
        assert (time is None or len(x)==len(y)==len(time))
        self.set_len(lenx, leny, overlap)

    def set_len(self, lenx:int, leny:int, overlap=0):
        assert len(self.x)-lenx-leny+overlap>=0
        assert overlap<=min(lenx, leny)
        self.lenx = lenx
        self.leny = leny
        self.overlap = overlap

    def __len__(self):
        return len(self.x)-self.lenx-self.leny+1

    def __getitem__(self, index):
        xbegin = index
        xend = index + self.lenx
        ybegin = index+self.lenx - self.overlap
        yend = ybegin+self.leny
        if self.time is None:
            x,y = self.x[xbegin:xend], self.y[ybegin:yend]
            x = torch.Tensor(x).unsqueeze(-1)
            y = torch.Tensor(y).unsqueeze(-1)
            return x,y
        else:
            x,y, xmark, ymark = self.x[xbegin:xend], self.y[ybegin:yend], self.time[xbegin:xend], self.time[ybegin:yend]
            x = torch.Tensor(x).unsqueeze(-1)
            y = torch.Tensor(y).unsqueeze(-1)
            return x,y, xmark, ymark

class Traffic(ConcatDataset):
    def __init__(self, root=os.path.join(os.path.dirname(os.path.abspath(__file__))), split='train', lenx=96, leny=24, scale=True, timeenc=0, freq='h', overlap=0):
        # size [seq_len, label_len, pred_len]
        # info
        self.lenx = lenx
        self.leny = leny
        self.overlap = overlap
        # init
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq
        self.root = root
        self.data_path = 'traffic.csv'
        self.split = split
        datasets, self.timestamps = self.__read_data__()
        super().__init__(datasets)

    def set_len(self, lenx:int, leny:int, overlap:int=0):
        for dataset in self.datasets:
            dataset.set_len(lenx, leny, overlap)
        self.cumulative_sizes = self.cumsum(self.datasets)

    def __read_data__(self):
        self.scaler = StandardScaler()
        data_path = os.path.join(self.root, self.data_path)
        if not os.path.exists(data_path):
            raise FileNotFoundError(f"{data_path} was not found. Please download traffic.csv from https://github.com/thuml/Autoformer")
        df_raw = pd.read_csv(data_path)
        # cols = list(df_raw.columns);
        df_stamp = df_raw[['date']][:]
        df_stamp['date'] = pd.to_datetime(df_stamp.date)
        data_stamp = time_features(df_stamp, timeenc=self.timeenc, freq=self.freq)
        all_data = []
        cols = list(df_raw.columns)
        cols.remove('date')
        df_data = df_raw[cols]
        k = int(len(cols)*0.8)
        if self.scale:
            self.scaler.fit(df_data.values)
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values
        if self.split=='train':
            for cid in range(k):
                col = cols[cid]
                x = y = data[:, cid]
                cdata = IndividualDataset(x,y, self.lenx, self.leny, data_stamp, col, overlap=self.overlap)
                all_data.append(cdata)
        else:
            for cid in range(k, len(cols)):
                col = cols[cid]
                x = y = data[:, cid]
                cdata = IndividualDataset(x,y, self.lenx, self.leny, data_stamp, col, overlap=self.overlap)
                all_data.append(cdata)
        return all_data, data_stamp

class Model(torch.nn.Module):
    def __init__(self, hidden_size=16, dim_in=1, dim_out=1, out_len=24, num_layers=2):
        super(Model, self).__init__()
        self.encoder = torch.nn.RNN(dim_in, hidden_size, num_layers)
        self.fc = torch.nn.Linear(hidden_size * num_layers, out_len * dim_out)
        self.out_len = out_len
        self.dim_out = dim_out

    def forward(self, x, *args, **kwargs):  # [B, W, M]
        x = x.permute([1, 0, 2]) # [W, B, M]
        _, h = self.encoder(x)  # [4, B, h]
        h = h.permute([1, 0, 2]).contiguous()  # [B, 4, h]
        h = h.view(h.shape[0], -1)  # [B, 4*h]
        x = self.fc(h)  # [B, M]
        x = x.reshape(x.shape[0], self.out_len, self.dim_out)
        return x

train_data = Traffic()
val_data = None
test_data = Traffic(split='test')
def get_model(*args, **kwargs) -> torch.nn.Module:
    return Model()

class TimeFeature:
    def __init__(self):
        pass

    def __call__(self, index: pd.DatetimeIndex) -> np.ndarray:
        pass

    def __repr__(self):
        return self.__class__.__name__ + "()"

class SecondOfMinute(TimeFeature):
    """Minute of hour encoded as value between [-0.5, 0.5]"""
    def __call__(self, index: pd.DatetimeIndex) -> np.ndarray:
        return index.second / 59.0 - 0.5

class MinuteOfHour(TimeFeature):
    """Minute of hour encoded as value between [-0.5, 0.5]"""
    def __call__(self, index: pd.DatetimeIndex) -> np.ndarray:
        return index.minute / 59.0 - 0.5

class HourOfDay(TimeFeature):
    """Hour of day encoded as value between [-0.5, 0.5]"""
    def __call__(self, index: pd.DatetimeIndex) -> np.ndarray:
        return index.hour / 23.0 - 0.5

class DayOfWeek(TimeFeature):
    """Hour of day encoded as value between [-0.5, 0.5]"""
    def __call__(self, index: pd.DatetimeIndex) -> np.ndarray:
        return index.dayofweek / 6.0 - 0.5

class DayOfMonth(TimeFeature):
    """Day of month encoded as value between [-0.5, 0.5]"""
    def __call__(self, index: pd.DatetimeIndex) -> np.ndarray:
        return (index.day - 1) / 30.0 - 0.5

class DayOfYear(TimeFeature):
    """Day of year encoded as value between [-0.5, 0.5]"""
    def __call__(self, index: pd.DatetimeIndex) -> np.ndarray:
        return (index.dayofyear - 1) / 365.0 - 0.5

class MonthOfYear(TimeFeature):
    """Month of year encoded as value between [-0.5, 0.5]"""
    def __call__(self, index: pd.DatetimeIndex) -> np.ndarray:
        return (index.month - 1) / 11.0 - 0.5

class WeekOfYear(TimeFeature):
    """Week of year encoded as value between [-0.5, 0.5]"""
    def __call__(self, index: pd.DatetimeIndex) -> np.ndarray:
        return (index.week - 1) / 52.0 - 0.5

def time_features_from_frequency_str(freq_str: str) -> List[TimeFeature]:
    """
    Returns a list of time features that will be appropriate for the given frequency string.
    Parameters
    ----------
    freq_str
        Frequency string of the form [multiple][granularity] such as "12H", "5min", "1D" etc.
    """

    features_by_offsets = {
        offsets.YearEnd: [],
        offsets.QuarterEnd: [MonthOfYear],
        offsets.MonthEnd: [MonthOfYear],
        offsets.Week: [DayOfMonth, WeekOfYear],
        offsets.Day: [DayOfWeek, DayOfMonth, DayOfYear],
        offsets.BusinessDay: [DayOfWeek, DayOfMonth, DayOfYear],
        offsets.Hour: [HourOfDay, DayOfWeek, DayOfMonth, DayOfYear],
        offsets.Minute: [
            MinuteOfHour,
            HourOfDay,
            DayOfWeek,
            DayOfMonth,
            DayOfYear,
        ],
        offsets.Second: [
            SecondOfMinute,
            MinuteOfHour,
            HourOfDay,
            DayOfWeek,
            DayOfMonth,
            DayOfYear,
        ],
    }

    offset = to_offset(freq_str)

    for offset_type, feature_classes in features_by_offsets.items():
        if isinstance(offset, offset_type):
            return [cls() for cls in feature_classes]

    supported_freq_msg = f"""
    Unsupported frequency {freq_str}
    The following frequencies are supported:
        Y   - yearly
            alias: A
        M   - monthly
        W   - weekly
        D   - daily
        B   - business days
        H   - hourly
        T   - minutely
            alias: min
        S   - secondly
    """
    raise RuntimeError(supported_freq_msg)

