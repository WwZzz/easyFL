from flgo.benchmark.leaf_sent140.model import stackedlstm
default_model = stackedlstm