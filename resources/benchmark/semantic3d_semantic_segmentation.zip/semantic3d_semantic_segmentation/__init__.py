"""
This benchmark is based on the github repo https://github.com/aRI0U/RandLA-Net-pytorch .
Before using this benchmark, u should manually download the raw data and preprocessed the raw data by scripts provided by the repo.
The preprocessed data can be stored in any path. The variable `dir` in config.py should be modified to the directory of the modified one.
"""
from .model import RandLANet
import flgo.benchmark.toolkits.visualization
import flgo.benchmark.toolkits.partition

default_model = RandLANet
default_partitioner = flgo.benchmark.toolkits.partition.IIDPartitioner
default_partition_para = {'num_clients':100}
# visualize = flgo.benchmark.toolkits.visualization.visualize_by_class

