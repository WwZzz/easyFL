import numpy as np
from pathlib import Path
import torch
from torch.utils.data import Dataset

# replace the path by the directory of the preprocessed data
dir = Path('~/dataset/subsampled')

class PointCloudsDataset(Dataset):
    def __init__(self, dir):
        self.paths = list(dir.glob(f'*.npy'))
        self.scene = [_ for _ in range(len(self))]

    def __getitem__(self, idx):
        path = self.paths[idx]

        points, labels = self.load_npy(path)

        points_tensor = torch.from_numpy(points).float()
        labels_tensor = torch.from_numpy(labels).long()

        return points_tensor, labels_tensor

    def __len__(self):
        return len(self.paths)

    def load_npy(self, path):
        r"""
            load the point cloud and labels of the npy file located in path

            Args:
                path: str
                    path of the point cloud
                keep_zeros: bool (optional)
                    keep unclassified points
        """
        cloud_npy = np.load(path, mmap_mode='r').T
        points = cloud_npy[:,:-1]

        labels = cloud_npy[:,-1]

        # balance training set
        points_list, labels_list = [], []
        for i in range(len(np.unique(labels))):
            try:
                idx = np.random.choice(len(labels[labels==i]), 8000)
                points_list.append(points[labels==i][idx])
                labels_list.append(labels[labels==i][idx])
            except ValueError:
                continue
        if points_list:
            points = np.stack(points_list)
            labels = np.stack(labels_list)
            labeled = labels>0
            points = points[labeled]
            labels = labels[labeled]
        return points, labels - 1

train_data = PointCloudsDataset(dir / 'train')
val_data = PointCloudsDataset(dir / 'val')
train_data.num_classes = 8
val_data.num_classes = 8