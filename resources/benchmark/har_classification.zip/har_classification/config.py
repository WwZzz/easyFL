import numpy as np
import torch
from torch.utils.data import Dataset, ConcatDataset
import os
from torchvision.datasets.utils import download_and_extract_archive
class IndividualDataset(Dataset):
    def __init__(self, x, y, name=None):
        self.x = x
        self.y = y
        self.name = name

    def __len__(self):
        return len(self.x)

    def __getitem__(self, item):
        return torch.Tensor(self.x[item]), torch.LongTensor(self.y[item]).squeeze(0)

class UCIHAR(ConcatDataset):
    INPUT_SIGNAL_TYPES = [
        "body_acc_x_",
        "body_acc_y_",
        "body_acc_z_",
        "body_gyro_x_",
        "body_gyro_y_",
        "body_gyro_z_",
        "total_acc_x_",
        "total_acc_y_",
        "total_acc_z_"
    ]

    # Output classes to learn how to classify
    LABELS = [
        "WALKING",
        "WALKING_UPSTAIRS",
        "WALKING_DOWNSTAIRS",
        "SITTING",
        "STANDING",
        "LAYING"
    ]
    TRAIN = "train"
    TEST = "test"
    DATASET_PATH = 'UCI HAR Dataset'
    def __init__(self, root=os.path.join(os.path.dirname(os.path.abspath(__file__))), split='train'):
        self.split = split
        self.root = root
        self.download()
        datasets, self.id = self.read_data()
        super(UCIHAR, self).__init__(datasets)

    def download(self):
        if not os.path.exists(os.path.join(self.root, self.DATASET_PATH)):
            download_and_extract_archive('http://archive.ics.uci.edu/static/public/240/human+activity+recognition+using+smartphones.zip', self.root)
            import zipfile
            f = zipfile.ZipFile(os.path.join(self.root, 'UCI HAR Dataset.zip'))
            f.extractall(self.root)
        return

    def load_y(self, y_path):
        file = open(y_path, 'r')
        # Read dataset from disk, dealing with text file's syntax
        y_ = np.array(
            [elem for elem in [
                row.replace('  ', ' ').strip().split(' ') for row in file
            ]],
            dtype=np.int32
        )
        file.close()
        # Substract 1 to each output class for friendly 0-based indexing
        return y_ - 1

    def load_X(self, X_signals_paths):
        X_signals = []
        for signal_type_path in X_signals_paths:
            file = open(signal_type_path, 'r')
            # Read dataset from disk, dealing with text files' syntax
            X_signals.append(
                [np.array(serie, dtype=np.float32) for serie in [
                    row.replace('  ', ' ').strip().split(' ') for row in file
                ]]
            )
            file.close()
        return np.transpose(np.array(X_signals), (1, 2, 0))

    def read_data(self):
        all_data = []
        if self.split=='train':
            Xpaths = [
                os.path.join(self.root, self.DATASET_PATH,self.TRAIN,"Inertial Signals",signal+"train.txt") for signal in self.INPUT_SIGNAL_TYPES
            ]
            ypath = os.path.join(self.root, self.DATASET_PATH, self.TRAIN,"y_train.txt")
            idpath = os.path.join(self.root, self.DATASET_PATH, self.TRAIN, 'subject_train.txt',)
        else:
            Xpaths = [
                os.path.join(self.root, self.DATASET_PATH, self.TEST, "Inertial Signals", signal+"test.txt") for signal in self.INPUT_SIGNAL_TYPES
            ]
            ypath = os.path.join(self.root, self.DATASET_PATH, self.TEST, "y_test.txt")
            idpath = os.path.join(self.root, self.DATASET_PATH, self.TEST, 'subject_test.txt', )
        X = self.load_X(Xpaths)
        y = self.load_y(ypath)
        file_id = open(idpath, 'r')
        ids = np.array([elem for elem in [row.replace('  ', ' ').strip().split(' ') for row in file_id]], dtype=np.int32).reshape(-1)
        all_id = set(ids.tolist())
        for cid in all_id:
            cid_idx = np.where(ids==cid)[0]
            X_i = X[cid_idx]
            y_i = y[cid_idx]
            all_data.append(IndividualDataset(X_i, y_i, cid))
        return all_data, ids

train_data = UCIHAR(split='train')
val_data = None
test_data = UCIHAR(split='test')

class Model(torch.nn.Module):
    def __init__(self, hidden_size=64, dim_feature=9, num_layers=2, num_classes=6):
        super(Model, self).__init__()
        self.encoder = torch.nn.RNN(dim_feature, hidden_size, num_layers)
        self.fc = torch.nn.Linear(hidden_size * num_layers, num_classes)

    def forward(self, x, *args, **kwargs):  # [B, W, M]
        x = x.permute([1, 0, 2]) # [W, B, M]
        _, h = self.encoder(x)  # [4, B, h]
        h = h.permute([1, 0, 2]).contiguous()  # [B, 4, h]
        h = h.view(h.shape[0], -1)  # [B, 4*h]
        x = self.fc(h)  # [B, M]
        return x

def get_model(*args, **kwargs):
    return Model()