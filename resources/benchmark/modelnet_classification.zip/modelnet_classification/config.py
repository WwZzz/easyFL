import os
import numpy as np
import pickle

import torch
import torch.nn as nn
from tqdm import tqdm
from torch.utils.data import Dataset
from flgo.benchmark.toolkits.cv.point_cloud_classification.pointnet_utils import PointNetEncoder, feature_transform_reguliarzer
import torch.nn.functional as F
from torchvision.datasets.utils import download_and_extract_archive, extract_archive
path = os.path.dirname(__file__)
def pc_normalize(pc):
    centroid = np.mean(pc, axis=0)
    pc = pc - centroid
    m = np.max(np.sqrt(np.sum(pc ** 2, axis=1)))
    pc = pc / m
    return pc

def farthest_point_sample(point, npoint):
    """
    Input:
        xyz: pointcloud data, [N, D]
        npoint: number of samples
    Return:
        centroids: sampled pointcloud index, [npoint, D]
    """
    N, D = point.shape
    xyz = point[:, :3]
    centroids = np.zeros((npoint,))
    distance = np.ones((N,)) * 1e10
    farthest = np.random.randint(0, N)
    for i in range(npoint):
        centroids[i] = farthest
        centroid = xyz[farthest, :]
        dist = np.sum((xyz - centroid) ** 2, -1)
        mask = dist < distance
        distance[mask] = dist[mask]
        farthest = np.argmax(distance, -1)
    point = point[centroids.astype(np.int32)]
    return point

class ModelNet(Dataset):
    url = "https://shapenet.cs.stanford.edu/media/modelnet40_normal_resampled.zip"
    def __init__(self, root, npoints=2500, split='train', process_data=False, num_classes = 40, uniform = False, use_normals=False):
        self.root = root
        self.split = split
        self.npoints = npoints
        self.process_data = process_data
        self.uniform = uniform
        self.use_normals = use_normals
        if not os.path.exists(os.path.join(self.root, 'modelnet40_normal_resampled')):
            zipfile = os.path.join(self.root, 'modelnet40_normal_resampled.zip')
            if os.path.exists(zipfile):
                extract_archive(zipfile, self.root, remove_finished=True)
            else:
                download_and_extract_archive(self.url, self.root, remove_finished=True)

        assert (self.split == 'train' or self.split == 'test')
        self.set_classes(num_classes)

    def set_classes(self, num_classes=40):
        self.num_classes = num_classes

        if self.num_classes == 10:
            self.catfile = os.path.join(self.root, 'modelnet40_normal_resampled','modelnet10_shape_names.txt')
        else:
            self.catfile = os.path.join(self.root, 'modelnet40_normal_resampled', 'modelnet40_shape_names.txt')

        self.cat = [line.rstrip() for line in open(self.catfile)]
        self.classes = dict(zip(self.cat, range(len(self.cat))))

        shape_ids = {}
        if self.num_classes == 10:
            shape_ids['train'] = [line.rstrip() for line in open(os.path.join(self.root,'modelnet40_normal_resampled', 'modelnet10_train.txt'))]
            shape_ids['test'] = [line.rstrip() for line in open(os.path.join(self.root, 'modelnet40_normal_resampled','modelnet10_test.txt'))]
        else:
            shape_ids['train'] = [line.rstrip() for line in open(os.path.join(self.root,'modelnet40_normal_resampled', 'modelnet40_train.txt'))]
            shape_ids['test'] = [line.rstrip() for line in open(os.path.join(self.root, 'modelnet40_normal_resampled', 'modelnet40_test.txt'))]

        shape_names = ['_'.join(x.split('_')[0:-1]) for x in shape_ids[self.split]]
        self.datapath = [(shape_names[i], os.path.join(self.root, 'modelnet40_normal_resampled', shape_names[i], shape_ids[self.split][i]) + '.txt') for i
                         in range(len(shape_ids[self.split]))]
        print('The size of %s data is %d' % (self.split, len(self.datapath)))
        self.set_uniform(self.uniform)

    def set_uniform(self, uniform):
        self.uniform = uniform
        if self.uniform:
            self.save_path = os.path.join(self.root,'modelnet40_normal_resampled',
                                          'modelnet%d_%s_%dpts_fps.dat' % (self.num_classes, self.split, self.npoints))
        else:
            self.save_path = os.path.join(self.root, 'modelnet40_normal_resampled','modelnet%d_%s_%dpts.dat' % (self.num_classes, self.split, self.npoints))

        if self.process_data:
            if not os.path.exists(self.save_path):
                print('Processing data %s (only running in the first time)...' % self.save_path)
                self.list_of_points = [None] * len(self.datapath)
                self.list_of_labels = [None] * len(self.datapath)

                for index in tqdm(range(len(self.datapath)), total=len(self.datapath)):
                    fn = self.datapath[index]
                    cls = self.classes[self.datapath[index][0]]
                    cls = np.array([cls]).astype(np.int32)
                    point_set = np.loadtxt(fn[1], delimiter=',').astype(np.float32)

                    if self.uniform:
                        point_set = farthest_point_sample(point_set, self.npoints)
                    else:
                        point_set = point_set[0:self.npoints, :]

                    self.list_of_points[index] = point_set
                    self.list_of_labels[index] = cls

                with open(self.save_path, 'wb') as f:
                    pickle.dump([self.list_of_points, self.list_of_labels], f)
            else:
                print('Load processed data from %s...' % self.save_path)
                with open(self.save_path, 'rb') as f:
                    self.list_of_points, self.list_of_labels = pickle.load(f)

    def set_use_normals(self,use_normals):
        self.use_normals = use_normals

    def __len__(self):
        return len(self.datapath)

    def _get_item(self, index):
        if self.process_data:
            point_set, label = self.list_of_points[index], self.list_of_labels[index]
        else:
            fn = self.datapath[index]
            cls = self.classes[self.datapath[index][0]]
            label = np.array([cls]).astype(np.int32)
            point_set = np.loadtxt(fn[1], delimiter=',').astype(np.float32)

            if self.uniform:
                point_set = farthest_point_sample(point_set, self.npoints)
            else:
                point_set = point_set[0:self.npoints, :]

        point_set[:, 0:3] = pc_normalize(point_set[:, 0:3])
        if not self.use_normals:
            point_set = point_set[:, 0:3]

        return torch.from_numpy(point_set), torch.from_numpy(label).long()

    def __getitem__(self, index):
        return self._get_item(index)

train_data = ModelNet(root=path, split='train', process_data=True, uniform=False, use_normals=True)
test_data = ModelNet(root=path, split='test', process_data=True, uniform=False, use_normals=True)

class PointNetCls(nn.Module):
    def __init__(self, k=40, normal_channel=True):
        super(PointNetCls, self).__init__()
        if normal_channel:
            channel = 6
        else:
            channel = 3
        self.feat = PointNetEncoder(global_feat=True, feature_transform=True, channel=channel)
        self.fc1 = nn.Linear(1024, 512)
        self.fc2 = nn.Linear(512, 256)
        self.fc3 = nn.Linear(256, k)
        self.dropout = nn.Dropout(p=0.4)
        self.bn1 = nn.BatchNorm1d(512)
        self.bn2 = nn.BatchNorm1d(256)
        self.relu = nn.ReLU()

    def forward(self, x):
        x, trans, trans_feat = self.feat(x)
        x = F.relu(self.bn1(self.fc1(x)))
        x = F.relu(self.bn2(self.dropout(self.fc2(x))))
        x = self.fc3(x)
        x = F.log_softmax(x, dim=1)
        return x
        # return x, trans_feat

def get_model():
    return PointNetCls(k=train_data.num_classes, normal_channel=train_data.use_normals)
