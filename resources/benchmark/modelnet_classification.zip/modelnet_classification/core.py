import os
import ujson as json
from flgo.benchmark.toolkits.cv.point_cloud_classification import GeneralCalculator, FromDatasetPipe, FromDatasetGenerator
from .config import train_data
try:
    from .config import test_data
except:
    test_data = None
try:
    from .config import val_data
except:
    val_data = None

class TaskGenerator(FromDatasetGenerator):
    def __init__(self, num_classes=40, uniform=False, use_normals=True):
        self.num_classes = num_classes
        self.uniform = uniform
        self.use_normals = use_normals
        if train_data is not None:
            train_data.set_classes(num_classes)
            train_data.set_uniform(uniform)
            train_data.set_use_normals(use_normals)
        if test_data is not None:
            test_data.set_classes(num_classes)
            test_data.set_uniform(uniform)
            test_data.set_use_normals(use_normals)
        super(TaskGenerator, self).__init__(benchmark=os.path.split(os.path.dirname(__file__))[-1], train_data=train_data, val_data=val_data, test_data=test_data)

class TaskPipe(FromDatasetPipe):
    def __init__(self, task_path):
        super(TaskPipe, self).__init__(task_path, train_data=train_data, val_data=val_data, test_data=test_data)
        if hasattr(self, 'feddata'):
            num_classes = self.feddata['num_classes']
            uniform = self.feddata['uniform']
            use_normals = self.feddata['use_normals']
            if self.train_data is not None:
                self.train_data.set_classes(num_classes)
                self.train_data.set_uniform(uniform)
                self.train_data.set_use_normals(use_normals)
            if test_data is not None:
                self.test_data.set_classes(num_classes)
                self.test_data.set_uniform(uniform)
                self.test_data.set_use_normals(use_normals)

    def save_task(self, generator):
        client_names = self.gen_client_names(len(generator.local_datas))
        feddata = {'client_names': client_names, 'num_classes':generator.num_classes, 'uniform': generator.uniform, 'use_normals':generator.use_normals}
        for cid in range(len(client_names)): feddata[client_names[cid]] = {'data': generator.local_datas[cid],}
        if hasattr(generator.partitioner, 'local_perturbation'): feddata['local_perturbation'] = generator.partitioner.local_perturbation
        with open(os.path.join(self.task_path, 'data.json'), 'w') as outf:
            json.dump(feddata, outf)
        return

TaskCalculator = GeneralCalculator