from flgo.benchmark.distributed_quadratic_programming.model import vec

default_model = vec