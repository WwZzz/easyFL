import torch
from torch.utils.data import Dataset, ConcatDataset
import os
import wfdb
import numpy as np
import pywt
from torchvision.datasets.utils import download_and_extract_archive
import torch.nn as nn

class IndividualDataset(Dataset):
    def __init__(self, x, y, time=None, name=None):
        self.x = x
        self.y = y
        self.time = time
        self.name = name
        assert (time is None or len(x)==len(y)==len(time))

    def __len__(self):
        return len(self.y)

    def __getitem__(self, index):
        return torch.from_numpy(self.x[index]).float(), torch.tensor(self.y[index], dtype=torch.int64)

class MITBIH(ConcatDataset):
    url = "https://www.physionet.org/static/published-projects/mitdb/mit-bih-arrhythmia-database-1.0.0.zip"
    def __init__(self, root=os.path.join(os.path.dirname(os.path.abspath(__file__))), split='train'):
        self.root = root
        self.split = split
        self.dirname = "mit-bih-arrhythmia-database-1.0.0"
        self.download()
        datasets = self.load_data()
        super(MITBIH, self).__init__(datasets)

    def download(self):
        path = os.path.join(self.root, self.dirname)
        if not os.path.exists(path):
            download_and_extract_archive(self.url, self.root)

    def denoise(self, data):
        coeffs = pywt.wavedec(data=data, wavelet='db5', level=9)
        cA9, cD9, cD8, cD7, cD6, cD5, cD4, cD3, cD2, cD1 = coeffs
        threshold = (np.median(np.abs(cD1)) / 0.6745) * (np.sqrt(2 * np.log(len(cD1))))
        cD1.fill(0)
        cD2.fill(0)
        for i in range(1, len(coeffs) - 2):
            coeffs[i] = pywt.threshold(coeffs[i], threshold)
        rdata = pywt.waverec(coeffs=coeffs, wavelet='db5')
        return rdata

    def load_data_from_file(self, number):
        X_data, Y_data = [], []
        ecgClassSet = ['N', 'A', 'V', 'L', 'R']
        path = os.path.join(self.root, self.dirname, str(number))
        record = wfdb.rdrecord(path, channel_names=['MLII'])
        data = record.p_signal.flatten()
        rdata = self.denoise(data=data)
        annotation = wfdb.rdann(path, 'atr')
        Rlocation = annotation.sample
        Rclass = annotation.symbol
        start = 10
        end = 5
        i = start
        j = len(annotation.symbol) - end
        while i < j:
            try:
                lable = ecgClassSet.index(Rclass[i])
                x_train = rdata[Rlocation[i] - 100:Rlocation[i] + 200]
                X_data.append(x_train)
                Y_data.append(lable)
                i += 1
            except ValueError:
                i += 1
        return X_data, Y_data

    def load_data(self):
        all_number = ['100', '101', '103', '105', '106', '107', '108', '109', '111', '112', '113', '114', '115',
                     '116', '117', '119', '121', '122', '123', '124', '200', '201', '202', '203', '205', '208',
                     '210', '212', '213', '214', '215', '217', '219', '220', '221', '222', '223', '228', '230',
                     '231', '232', '233', '234']
        train_number = ['100', '101', '103', '105', '106', '107', '108', '109', '112', '113', '114', '115', '116', '119', '121', '123', '200', '201', '202', '205', '208', '210', '212', '213', '214', '215', '217', '219', '221', '222', '230', '231', '232', '234']
        test_number = list(set(all_number).difference(train_number))
        if self.split=='train': numbers = train_number
        elif self.split=='test': numbers = test_number
        elif self.split=='all': numbers = all_number
        else:
            raise ValueError(f"Parameter split must be one of ['train', 'test', 'all']")
        all_data = []
        for i, n in enumerate(numbers):
            xn, yn = self.load_data_from_file(n)
            xn = np.array(xn).reshape(-1, 300, 1)
            yn = np.array(yn)
            ndata = IndividualDataset(xn, yn, name=n)
            all_data.append(ndata)
        return all_data

class Model(nn.Module):
    def __init__(self):
        super(Model, self).__init__()
        self.rnn = nn.RNN(1, 50, 3, nonlinearity='tanh')
        self.linear = nn.Linear(50, 5)

    def forward(self, x):
        r_out, h_state = self.rnn(x)
        output = self.linear(r_out[:, -1, :])  # 将 RNN 层的输出 r_out 在最后一个时间步上的输出（隐藏状态）传递给线性层
        return output

train_data = MITBIH()
val_data = None
test_data = MITBIH(split='test')

def get_model():
    return Model()


