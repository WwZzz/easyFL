import os
import sys
import glob
import h5py
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from flgo.benchmark.toolkits.cv.points_classification.pointnet_utils import feature_transform_reguliarzer, PointNetEncoder
from torch.utils.data import Dataset
from torchvision.datasets.utils import download_and_extract_archive, extract_archive
path = os.path.dirname(__file__)

def load_scanobjectnn(root, split):
    # download_scanobjectnn()
    h5_name = os.path.join(root, 'h5_files/main_split/', '%s_objectdataset_augmentedrot_scale75.h5' % split)
    f = h5py.File(h5_name, 'r')
    all_data = f['data'][:].astype('float32')
    all_label = f['label'][:].astype('int64')
    f.close()
    return all_data, all_label

def translate_pointcloud(pointcloud):
    '''
    Randomly scale and shift point cloud
    '''
    xyz1 = np.random.uniform(low=2. / 3., high=3. / 2., size=[3])
    xyz2 = np.random.uniform(low=-0.2, high=0.2, size=[3])

    translated_pointcloud = np.add(np.multiply(pointcloud, xyz1), xyz2).astype('float32')
    return translated_pointcloud

class ScanObjectNN(Dataset):
    url = 'https://hkust-vgd.ust.hk/scanobjectnn/h5_files.zip'
    def __init__(self, root=path, npoints=1024, split='training'):
        if not os.path.exists(os.path.join(root, 'h5_files')):
            zipfile = os.path.join(root, 'h5_files.zip')
            if not os.path.exists(zipfile):
                download_and_extract_archive(self.url, root, remove_finished=True)
            else:
                extract_archive(zipfile, root, remove_finished=True)
        self.data, self.label = load_scanobjectnn(root, split)
        self.npoints = npoints
        self.split = split

    def __getitem__(self, item):
        pointcloud = self.data[item][:self.npoints]
        label = self.label[item]
        if self.split == 'train':
            pointcloud = translate_pointcloud(pointcloud)
            np.random.shuffle(pointcloud)
        pointcloud = torch.from_numpy(pointcloud).float()
        label = torch.tensor([label]).long()
        return pointcloud, label

    def __len__(self):
        return self.data.shape[0]

train_data = ScanObjectNN(path, split='training')
test_data = ScanObjectNN(path, split='test')
train_data.num_classes = 15
test_data.num_classes = 15

class PointNetCls(nn.Module):
    def __init__(self, k=15, normal_channel=False):
        super(PointNetCls, self).__init__()
        if normal_channel:
            channel = 6
        else:
            channel = 3
        self.feat = PointNetEncoder(global_feat=True, feature_transform=True, channel=channel)
        self.fc1 = nn.Linear(1024, 512)
        self.fc2 = nn.Linear(512, 256)
        self.fc3 = nn.Linear(256, k)
        self.dropout = nn.Dropout(p=0.4)
        self.bn1 = nn.BatchNorm1d(512)
        self.bn2 = nn.BatchNorm1d(256)
        self.relu = nn.ReLU()

    def forward(self, x):
        x, trans, trans_feat = self.feat(x)
        x = F.relu(self.bn1(self.fc1(x)))
        x = F.relu(self.bn2(self.dropout(self.fc2(x))))
        x = self.fc3(x)
        x = F.log_softmax(x, dim=1)
        if self.training:
            return x, trans, trans_feat
        else:
            return x

    def compute_loss(self, model_outputs, y):
        if self.training:
            ypred, trans, trans_feat = model_outputs
            loss = F.nll_loss(ypred, y)
            if trans_feat is not None:
                loss += 0.001 * feature_transform_reguliarzer(trans_feat)
            return loss
        else:
            return F.nll_loss(model_outputs, y)

def get_model():
    return PointNetCls(k=15, normal_channel=False)