from .dataset import nuScenes
path = ''
train_data = nuScenes(path, imageset='train')
test_data = nuScenes(path, imageset='test')
train_data.num_classes = 17
test_data.num_classes = 17

def get_model():
    return None

x = train_data[0]
print('ok')
