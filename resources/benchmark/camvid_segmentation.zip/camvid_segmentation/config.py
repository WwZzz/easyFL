import torch
import torchvision
from torch.utils.data import Dataset
import numpy as np  # linear algebra
import pandas as pd  # data processing, CSV file I/O (e.g. pd.read_csv)
from torchvision import transforms
import os
import cv2
from PIL import Image


class CamVID(Dataset):
    """CamVid Dataset. Read images, apply augmentation and preprocessing transformations.

    Args:
        root (str): raw data path
        split (str): train\val\test
        class_values (list): values of classes to extract from segmentation mask
        augmentation (albumentations.Compose): data transfromation pipeline
            (e.g. flip, scale, etc.)
        preprocessing (albumentations.Compose): data preprocessing
            (e.g. noralization, shape manipulation, etc.)"""
    CLASSES = ['Animal',
               'Archway',
               'Bicyclist',
               'Bridge',
               'Building',
               'Car',
               'CartLuggagePram',
               'Child',
               'Column_Pole',
               'Fence',
               'LaneMkgsDriv',
               'LaneMkgsNonDriv',
               'Misc_Text',
               'MotorcycleScooter',
               'OtherMoving',
               'ParkingBlock',
               'Pedestrian',
               'Road',
               'RoadShoulder',
               'Sidewalk',
               'SignSymbol',
               'Sky',
               'SUVPickupTruck',
               'TrafficCone',
               'TrafficLight',
               'Train',
               'Tree',
               'Truck_Bus',
               'Tunnel',
               'VegetationMisc',
               'Void',
               'Wall']
    CLASSES_RGB = [([64, 128, 64], 'Animal'),
                   ([192, 0, 128], 'Archway'),
                   ([0, 128, 192], 'Bicyclist'),
                   ([0, 128, 64], 'Bridge'),
                   ([128, 0, 0], 'Building'),
                   ([64, 0, 128], 'Car'),
                   ([64, 0, 192], 'CartLuggagePram'),
                   ([192, 128, 64], 'Child'),
                   ([192, 192, 128], 'Column_Pole'),
                   ([64, 64, 128], 'Fence'),
                   ([128, 0, 192], 'LaneMkgsDriv'),
                   ([192, 0, 64], 'LaneMkgsNonDriv'),
                   ([128, 128, 64], 'Misc_Text'),
                   ([192, 0, 192], 'MotorcycleScooter'),
                   ([128, 64, 64], 'OtherMoving'),
                   ([64, 192, 128], 'ParkingBlock'),
                   ([64, 64, 0], 'Pedestrian'),
                   ([128, 64, 128], 'Road'),
                   ([128, 128, 192], 'RoadShoulder'),
                   ([0, 0, 192], 'Sidewalk'),
                   ([192, 128, 128], 'SignSymbol'),
                   ([128, 128, 128], 'Sky'),
                   ([64, 128, 192], 'SUVPickupTruck'),
                   ([0, 0, 64], 'TrafficCone'),
                   ([0, 64, 64], 'TrafficLight'),
                   ([192, 64, 128], 'Train'),
                   ([128, 128, 0], 'Tree'),
                   ([192, 128, 192], 'Truck_Bus'),
                   ([64, 0, 64], 'Tunnel'),
                   ([192, 192, 0], 'VegetationMisc'),
                   ([0, 0, 0], 'Void'),
                   ([64, 192, 0], 'Wall')]

    def __init__(
            self,
            root,
            split='train',
            classes=None,
            transform=None,
            target_transform=None,
    ):
        images_dir = os.path.join(root, split)
        masks_dir = os.path.join(root, split + "_labels")
        self.classes = classes if classes is not None else self.CLASSES
        self.effective_class_id = [self.CLASSES.index(c) for c in self.classes]
        self.class_dict = {k[1]:k[0] for k in self.CLASSES_RGB}
        self.arr_col = list(self.class_dict.values())
        self.ids = os.listdir(images_dir)
        self.images_fps = [
            os.path.join(
                images_dir,
                image_id) for image_id in self.ids]
        self.masks_fps = [
            os.path.join(
                masks_dir,
                image_id.replace(
                    '.png',
                    '_L.png')) for image_id in self.ids]
        # convert str names to class values on masks
        self.transform = transform
        self.target_transform = target_transform

    def __getitem__(self, i):
        # read data
        # print(self.images_fps[i],self.masks_fps[i])
        image = cv2.imread(self.images_fps[i])
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        # image = Image.open(self.images_fps[i]).convert('RGB')
        # image = cv2.resize(image, (480, 320))
        mask = cv2.imread(self.masks_fps[i])
        mask = cv2.cvtColor(mask, cv2.COLOR_BGR2RGB)
        mask = self.color2index(mask, self.arr_col)
        mask = torch.from_numpy(np.array(mask)).long()
        if self.transform is not None:
            image = self.transform(image)
        if self.target_transform is not None:
            mask = self.target_transform(mask)
        return image, mask

    def color2index(self, y, arr_col):
        y_ind = np.zeros((y.shape[0], y.shape[1]))
        for i,i_color in enumerate(arr_col):
            ind_i = np.where(np.all(np.equal(y, i_color), axis=-1))
            y_ind[ind_i[0], ind_i[1]] = i if i in self.effective_class_id else 255
        return y_ind  # , i-1

    def __len__(self):
        return len(self.ids)

transform = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.485, 0.456, 0.406), (
    0.229, 0.224, 0.225))])  # transforms to tensor and normalize data

target_transform = None
path = os.path.join(os.path.dirname(__file__), 'CamVid')
train_data = CamVID(path, 'train', transform=transform,
                    target_transform=target_transform)
val_data = CamVID(path, 'val', transform=transform,
                  target_transform=target_transform)
test_data = CamVID(path, 'test', transform=transform,
                   target_transform=target_transform)
train_data.num_classes = len(train_data.classes)
test_data.num_classes = len(train_data.classes)
val_data.num_classes = len(train_data.classes)


def get_model():
    model = torchvision.models.segmentation.fcn_resnet50(
        num_classes=train_data.num_classes)
    return model
