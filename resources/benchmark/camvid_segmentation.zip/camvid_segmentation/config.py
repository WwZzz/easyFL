import torch
import torchvision
from torch.utils.data import Dataset
import numpy as np  # linear algebra
import pandas as pd  # data processing, CSV file I/O (e.g. pd.read_csv)
from torchvision import transforms
import os
import cv2


class CamVID(Dataset):
    """CamVid Dataset. Read images, apply augmentation and preprocessing transformations.

    Args:
        root (str): raw data path
        split (str): train\val\test
        class_values (list): values of classes to extract from segmentation mask
        augmentation (albumentations.Compose): data transfromation pipeline
            (e.g. flip, scale, etc.)
        preprocessing (albumentations.Compose): data preprocessing
            (e.g. noralization, shape manipulation, etc.)"""
    CLASSES = ['Animal',
               'Archway',
               'Bicyclist',
               'Bridge',
               'Building',
               'Car',
               'CartLuggagePram',
               'Child',
               'Column_Pole',
               'Fence',
               'LaneMkgsDriv',
               'LaneMkgsNonDriv',
               'Misc_Text',
               'MotorcycleScooter',
               'OtherMoving',
               'ParkingBlock',
               'Pedestrian',
               'Road',
               'RoadShoulder',
               'Sidewalk',
               'SignSymbol',
               'Sky',
               'SUVPickupTruck',
               'TrafficCone',
               'TrafficLight',
               'Train',
               'Tree',
               'Truck_Bus',
               'Tunnel',
               'VegetationMisc',
               'Void',
               'Wall']
    def __init__(
            self,
            root,
            split='train',
            classes=None,
            transform=None,
            target_transform=None,
    ):
        images_dir = os.path.join(root, split)
        masks_dir = os.path.join(root, split + "_labels")
        self.classes = classes if classes is not None else self.CLASSES
        gray_label_dict, _ = self.get_label_dict(self.classes)
        self.ids = os.listdir(images_dir)
        self.images_fps = [
            os.path.join(
                images_dir,
                image_id) for image_id in self.ids]
        self.masks_fps = [
            os.path.join(
                masks_dir,
                image_id.replace(
                    '.png',
                    '_L.png')) for image_id in self.ids]
        # convert str names to class values on masks
        self.class_values = list(gray_label_dict.values())
        self.transform = transform
        self.target_transform = target_transform

    def __getitem__(self, i):
        # read data
        # print(self.images_fps[i],self.masks_fps[i])
        image = cv2.imread(self.images_fps[i])
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        # image = cv2.resize(image, (480, 320))
        mask = cv2.imread(self.masks_fps[i])
        mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY)
        # mask = cv2.resize(image, (480, 320))
        masks = np.zeros(mask.shape, dtype=np.uint)
        # extract certain classes from mask (e.g. cars)
        masks = sum([(mask == v) * v for v in self.class_values])
        # print("class values",self.class_values)
        mask = np.array(masks).astype('float')
        # convert to tensor and long data type
        mask = torch.from_numpy(np.array(mask)).long()
        if self.transform is not None:
            image = self.transform(image)
        if self.target_transform is not None:
            mask = self.target_transform(mask)
        return image, mask

    def __len__(self):
        return len(self.ids)

    def get_label_dict(self, name_list):
        index = 0
        df = pd.read_csv("./CamVid/class_dict.csv")
        label_dict = dict()
        gray_label_dict = dict()
        for x, rows in enumerate(df.iterrows()):
            if rows[1]["name"] in name_list:
                rgb = [rows[1]['r'], rows[1]['g'], rows[1]['b']]
                gray = 0.299 * rows[1]['r'] + 0.587 * \
                    rows[1]['g'] + 0.114 * rows[1]['b']
                gray = np.uint8(gray)
                gray_label_dict[index] = gray
                label_dict[index] = rgb
                index = index + 1
        return gray_label_dict, label_dict


transform = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.485, 0.456, 0.406), (
    0.229, 0.224, 0.225))])  # transforms to tensor and normalize data

class_values =torch.LongTensor([101, 72, 97, 82, 38, 33, 41, 139, 184, 71, 60, 64, 120, 79, 83, 146, 56, 90, 135, 21, 147, 127, 116, 7, 44, 109, 113, 154, 26, 170, 0, 131])

def target_transform(y):
    shape = y.shape
    return (y.view(-1,1) == class_values).int().argmax(dim=1).reshape(shape)

path = os.path.join(os.path.dirname(__file__), 'CamVid')
train_data = CamVID(path, 'train', transform=transform, target_transform=target_transform)
val_data = CamVID(path, 'val', transform=transform, target_transform=target_transform)
test_data = CamVID(path, 'test', transform=transform, target_transform=target_transform)
train_data.num_classes = len(train_data.classes)
test_data.num_classes = len(train_data.classes)
val_data.num_classes = len(train_data.classes)

def get_model():
    model = torchvision.models.segmentation.fcn_resnet50(num_classes=train_data.num_classes)
    return model

