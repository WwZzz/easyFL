import os
from torch.utils.data import Dataset
import torchvision.transforms as T
import torch
import torchvision
import torchvision.datasets.utils
path = os.path.join(os.path.dirname(__file__))
from PIL import Image

class ADE20K(Dataset):
    """
    Args:
        root (str): the root path
        split (str): train or val
        download (bool): whether to download the raw data
    """

    url = 'http://data.csail.mit.edu/places/ADEchallenge/ADEChallengeData2016.zip'
    def __init__(self,  root:str, split:str='train', download:bool=True, transform=None, target_transform=None):
        self.root = root
        self.split = split
        sub_dir = 'training' if split=='train' else 'validation'
        self.root_img = os.path.join(root, 'ADEChallengeData2016', 'images', sub_dir)
        self.root_seg = os.path.join(root, 'ADEChallengeData2016', 'annotations', sub_dir)
        self.imgSize = 384
        self.segSize = 384
        # mean and std
        self.transform = transform
        self.target_transform = target_transform
        # check the existence of raw data
        zipfile = os.path.join(root, 'ADEChallengeData2016.zip')
        if not (os.path.exists(self.root_img) and os.path.exists(self.root_seg)):
            if not os.path.exists(zipfile):
                if download:
                    torchvision.datasets.utils.download_and_extract_archive(self.url, download_root=self.root, remove_finished=True)
                else:
                    raise FileNotFoundError("Please set download=True to download the raw data")
            else:
                try:
                    torchvision.datasets.utils.extract_archive(zipfile, self.root, remove_finished=True)
                except Exception as e:
                    print(e)
                    os.remove(zipfile)
                return
        self.list_sample = [x.rstrip() for x in os.listdir(self.root_img)]

    def __getitem__(self, index):
        img_basename = self.list_sample[index]
        path_img = os.path.join(self.root_img, img_basename)
        path_seg = os.path.join(self.root_seg, img_basename.replace('.jpg', '.png'))
        img = Image.open(path_img).convert('RGB')
        seg = Image.open(path_seg)
        if self.transform is not None: img = self.transform(img)
        if self.target_transform is not None: seg = self.target_transform(seg)
        return img, seg

    def __len__(self):
        return len(self.list_sample)

transform = T.Compose([
    T.ToTensor(),
    T.Normalize((0.485, 0.456, 0.406),
                (0.229, 0.224, 0.225))
])
target_transform = T.Compose([
    T.PILToTensor(),
    T.Lambda(lambda x: torch.squeeze(x-1).type(torch.LongTensor))
])
train_data = ADE20K(path, 'train', transform=transform, target_transform=target_transform)
test_data = ADE20K(path, 'val', transform=transform, target_transform=target_transform)
train_data.num_classes = 150
test_data.num_classes = 150

def get_model():
    model = torchvision.models.segmentation.fcn_resnet50(num_classes=train_data.num_classes)
    return model

