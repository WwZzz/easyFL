import torchvision
import os
import torchvision.transforms as T
import torch
transform = T.Compose([
    T.ToTensor(),
    T.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
])
target_transform = T.Compose([
    T.PILToTensor(),
    T.Lambda(lambda x: (x-1).squeeze().type(torch.LongTensor))
])
dirname = os.path.dirname(__file__)
path = os.path.join(dirname, 'cityspaces')
train_data = torchvision.datasets.Cityscapes(path, split='train', mode='fine',target_type='semantic', transform=transform, target_transform=target_transform)
test_data = torchvision.datasets.Cityscapes(path, split='test', mode='fine',target_type='semantic', transform=transform, target_transform=target_transform)
train_data.num_classes = len(train_data.classes)+1
test_data.num_classes = len(train_data.classes)+1

def get_model():
    model = torchvision.models.segmentation.fcn_resnet50(num_classes=train_data.num_classes)
    return model
