from flgo.benchmark.leaf_reddit.model import stackedlstm
default_model = stackedlstm
