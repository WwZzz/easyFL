from .dataset import SemanticKITTI
path = '/home/dataset/SemanticKITTI/sequences'
train_data = SemanticKITTI(path, split='train')
val_data = SemanticKITTI(path, split='val')
test_data = SemanticKITTI(path, split='test')
train_data.num_classes = 20
val_data.num_classes = 20
test_data.num_classes = 20

