import os
import numpy as np
from tqdm import tqdm
from torch.utils.data import Dataset
from torchvision.datasets.utils import extract_archive
from .indoor3d_util import collect_point_label
import torch
import torch.nn as nn
import torch.nn.parallel
import torch.utils.data
import torch.nn.functional as F
from flgo.benchmark.toolkits.cv.points_semantic_segmentation.pointnet_utils import PointNetEncoder, feature_transform_regularizer

path = os.path.dirname(__file__)
NUM_POINT = 4096
test_area = 5
class S3DISDataset(Dataset):
    def __init__(self, root, split='train', npoints=4096, test_area=5, block_size=1.0, sample_rate=1.0, transform=None):
        super().__init__()
        self.root = root
        if not os.path.exists(os.path.join(root, 'Stanford3dDataset_v1.2_Aligned_Version')):
            zipfile = os.path.join(root, 'Stanford3dDataset_v1.2_Aligned_Version.zip')
            if not os.path.exists(zipfile):
                raise FileNotFoundError("Dataset S3DIS doesn't exist. Please download this dataset at http://buildingparser.stanford.edu/dataset.html")
            else:
                extract_archive(zipfile, root, remove_finished=True)
        if not os.path.exists(os.path.join(self.root, 'stanford_indoor3d')):
            self.preprocess()
        self.npoints = npoints
        self.block_size = block_size
        self.transform = transform
        self.data_root = os.path.join(self.root, 'stanford_indoor3d')
        rooms = sorted(os.listdir(self.data_root))
        rooms = [room for room in rooms if 'Area_' in room]
        if split == 'train':
            rooms_split = [room for room in rooms if not 'Area_{}'.format(test_area) in room]
        else:
            rooms_split = [room for room in rooms if 'Area_{}'.format(test_area) in room]

        self.room_points, self.room_labels = [], []
        self.room_coord_min, self.room_coord_max = [], []
        num_point_all = []
        labelweights = np.zeros(13)

        for room_name in tqdm(rooms_split, total=len(rooms_split)):
            room_path = os.path.join(self.data_root, room_name)
            room_data = np.load(room_path)  # xyzrgbl, N*7
            points, labels = room_data[:, 0:6], room_data[:, 6]  # xyzrgb, N*6; l, N
            tmp, _ = np.histogram(labels, range(14))
            labelweights += tmp
            coord_min, coord_max = np.amin(points, axis=0)[:3], np.amax(points, axis=0)[:3]
            self.room_points.append(points), self.room_labels.append(labels)
            self.room_coord_min.append(coord_min), self.room_coord_max.append(coord_max)
            num_point_all.append(labels.size)
        labelweights = labelweights.astype(np.float32)
        labelweights = labelweights / np.sum(labelweights)
        self.labelweights = np.power(np.amax(labelweights) / labelweights, 1 / 3.0)
        print(self.labelweights)
        sample_prob = num_point_all / np.sum(num_point_all)
        num_iter = int(np.sum(num_point_all) * sample_rate / npoints)
        room_idxs = []
        for index in range(len(rooms_split)):
            room_idxs.extend([index] * int(round(sample_prob[index] * num_iter)))
        self.room_idxs = np.array(room_idxs)
        print("Totally {} samples in {} set.".format(len(self.room_idxs), split))

    def __getitem__(self, idx):
        room_idx = self.room_idxs[idx]
        points = self.room_points[room_idx]   # N * 6
        labels = self.room_labels[room_idx]   # N
        N_points = points.shape[0]

        while (True):
            center = points[np.random.choice(N_points)][:3]
            block_min = center - [self.block_size / 2.0, self.block_size / 2.0, 0]
            block_max = center + [self.block_size / 2.0, self.block_size / 2.0, 0]
            point_idxs = np.where((points[:, 0] >= block_min[0]) & (points[:, 0] <= block_max[0]) & (points[:, 1] >= block_min[1]) & (points[:, 1] <= block_max[1]))[0]
            if point_idxs.size > 1024:
                break

        if point_idxs.size >= self.npoints:
            selected_point_idxs = np.random.choice(point_idxs, self.npoints, replace=False)
        else:
            selected_point_idxs = np.random.choice(point_idxs, self.npoints, replace=True)

        # normalize
        selected_points = points[selected_point_idxs, :]  # num_point * 6
        current_points = np.zeros((self.npoints, 9))  # num_point * 9
        current_points[:, 6] = selected_points[:, 0] / self.room_coord_max[room_idx][0]
        current_points[:, 7] = selected_points[:, 1] / self.room_coord_max[room_idx][1]
        current_points[:, 8] = selected_points[:, 2] / self.room_coord_max[room_idx][2]
        selected_points[:, 0] = selected_points[:, 0] - center[0]
        selected_points[:, 1] = selected_points[:, 1] - center[1]
        selected_points[:, 3:6] /= 255.0
        current_points[:, 0:6] = selected_points
        current_labels = labels[selected_point_idxs]
        if self.transform is not None:
            current_points, current_labels = self.transform(current_points, current_labels)
        current_points = torch.from_numpy(current_points).float()
        current_labels = torch.from_numpy(current_labels).long()
        return current_points, current_labels

    def preprocess(self):
        DATA_PATH = os.path.join(self.root, 'Stanford3dDataset_v1.2_Aligned_Version')
        anno_paths = [line.rstrip() for line in open(os.path.join(self.root, 'meta/anno_paths.txt'))]
        anno_paths = [os.path.join(DATA_PATH, p) for p in anno_paths]

        output_folder = os.path.join(self.root, 'stanford_indoor3d')
        if not os.path.exists(output_folder): os.mkdir(output_folder)

        # Note: there is an extra character in the v1.2 data in Area_5/hallway_6. It's fixed manually.
        for anno_path in anno_paths:
            print(anno_path)
            try:
                elements = anno_path.split('/')
                out_filename = elements[-3] + '_' + elements[-2] + '.npy'  # Area_1_hallway_1.npy
                collect_point_label(anno_path, os.path.join(output_folder, out_filename), 'numpy')
            except:
                print(anno_path, 'ERROR!!')
        return

    def __len__(self):
        return len(self.room_idxs)

class ScannetDatasetWholeScene():
    # prepare to give prediction on each points
    def __init__(self, root, block_points=4096, split='test', test_area=5, stride=0.5, block_size=1.0, padding=0.001):
        self.block_points = block_points
        self.block_size = block_size
        self.padding = padding
        self.root = root
        self.split = split
        self.stride = stride
        self.scene_points_num = []
        assert split in ['train', 'test']
        if self.split == 'train':
            self.file_list = [d for d in os.listdir(root) if d.find('Area_%d' % test_area) is -1]
        else:
            self.file_list = [d for d in os.listdir(root) if d.find('Area_%d' % test_area) is not -1]
        self.scene_points_list = []
        self.semantic_labels_list = []
        self.room_coord_min, self.room_coord_max = [], []
        for file in self.file_list:
            data = np.load(root + file)
            points = data[:, :3]
            self.scene_points_list.append(data[:, :6])
            self.semantic_labels_list.append(data[:, 6])
            coord_min, coord_max = np.amin(points, axis=0)[:3], np.amax(points, axis=0)[:3]
            self.room_coord_min.append(coord_min), self.room_coord_max.append(coord_max)
        assert len(self.scene_points_list) == len(self.semantic_labels_list)

        labelweights = np.zeros(13)
        for seg in self.semantic_labels_list:
            tmp, _ = np.histogram(seg, range(14))
            self.scene_points_num.append(seg.shape[0])
            labelweights += tmp
        labelweights = labelweights.astype(np.float32)
        labelweights = labelweights / np.sum(labelweights)
        self.labelweights = np.power(np.amax(labelweights) / labelweights, 1 / 3.0)

    def __getitem__(self, index):
        point_set_ini = self.scene_points_list[index]
        points = point_set_ini[:,:6]
        labels = self.semantic_labels_list[index]
        coord_min, coord_max = np.amin(points, axis=0)[:3], np.amax(points, axis=0)[:3]
        grid_x = int(np.ceil(float(coord_max[0] - coord_min[0] - self.block_size) / self.stride) + 1)
        grid_y = int(np.ceil(float(coord_max[1] - coord_min[1] - self.block_size) / self.stride) + 1)
        data_room, label_room, sample_weight, index_room = np.array([]), np.array([]), np.array([]),  np.array([])
        for index_y in range(0, grid_y):
            for index_x in range(0, grid_x):
                s_x = coord_min[0] + index_x * self.stride
                e_x = min(s_x + self.block_size, coord_max[0])
                s_x = e_x - self.block_size
                s_y = coord_min[1] + index_y * self.stride
                e_y = min(s_y + self.block_size, coord_max[1])
                s_y = e_y - self.block_size
                point_idxs = np.where(
                    (points[:, 0] >= s_x - self.padding) & (points[:, 0] <= e_x + self.padding) & (points[:, 1] >= s_y - self.padding) & (
                                points[:, 1] <= e_y + self.padding))[0]
                if point_idxs.size == 0:
                    continue
                num_batch = int(np.ceil(point_idxs.size / self.block_points))
                point_size = int(num_batch * self.block_points)
                replace = False if (point_size - point_idxs.size <= point_idxs.size) else True
                point_idxs_repeat = np.random.choice(point_idxs, point_size - point_idxs.size, replace=replace)
                point_idxs = np.concatenate((point_idxs, point_idxs_repeat))
                np.random.shuffle(point_idxs)
                data_batch = points[point_idxs, :]
                normlized_xyz = np.zeros((point_size, 3))
                normlized_xyz[:, 0] = data_batch[:, 0] / coord_max[0]
                normlized_xyz[:, 1] = data_batch[:, 1] / coord_max[1]
                normlized_xyz[:, 2] = data_batch[:, 2] / coord_max[2]
                data_batch[:, 0] = data_batch[:, 0] - (s_x + self.block_size / 2.0)
                data_batch[:, 1] = data_batch[:, 1] - (s_y + self.block_size / 2.0)
                data_batch[:, 3:6] /= 255.0
                data_batch = np.concatenate((data_batch, normlized_xyz), axis=1)
                label_batch = labels[point_idxs].astype(int)
                batch_weight = self.labelweights[label_batch]

                data_room = np.vstack([data_room, data_batch]) if data_room.size else data_batch
                label_room = np.hstack([label_room, label_batch]) if label_room.size else label_batch
                sample_weight = np.hstack([sample_weight, batch_weight]) if label_room.size else batch_weight
                index_room = np.hstack([index_room, point_idxs]) if index_room.size else point_idxs
        data_room = data_room.reshape((-1, self.block_points, data_room.shape[1]))
        label_room = label_room.reshape((-1, self.block_points))
        sample_weight = sample_weight.reshape((-1, self.block_points))
        index_room = index_room.reshape((-1, self.block_points))
        return data_room, label_room, sample_weight, index_room

    def __len__(self):
        return len(self.scene_points_list)

class PointNetSeg(nn.Module):
    def __init__(self, num_class=13):
        super(PointNetSeg, self).__init__()
        self.k = num_class
        self.feat = PointNetEncoder(global_feat=False, feature_transform=True, channel=9)
        self.conv1 = torch.nn.Conv1d(1088, 512, 1)
        self.conv2 = torch.nn.Conv1d(512, 256, 1)
        self.conv3 = torch.nn.Conv1d(256, 128, 1)
        self.conv4 = torch.nn.Conv1d(128, self.k, 1)
        self.bn1 = nn.BatchNorm1d(512)
        self.bn2 = nn.BatchNorm1d(256)
        self.bn3 = nn.BatchNorm1d(128)

    def forward(self, x):
        batchsize = x.size()[0]
        n_pts = x.size()[2]
        x, trans, trans_feat = self.feat(x)
        x = F.relu(self.bn1(self.conv1(x)))
        x = F.relu(self.bn2(self.conv2(x)))
        x = F.relu(self.bn3(self.conv3(x)))
        x = self.conv4(x)
        x = x.transpose(2,1).contiguous()
        x = F.log_softmax(x.view(-1,self.k), dim=-1)
        x = x.view(batchsize, n_pts, self.k)
        if self.training:
            return x, trans_feat
        else:
            return x

    def compute_loss(self, model_output, target, weight=None):
        if self.training:
            pred, trans_feat = model_output
            pred = pred.contiguous().view(-1, pred.shape[-1])
            target = target.view(-1, 1)[:, 0]
            loss = F.nll_loss(pred, target, weight=None)
            loss_reg = feature_transform_regularizer(trans_feat)
            loss += 0.001*loss_reg
        else:
            pred = model_output
            pred = pred.contiguous().view(-1, pred.shape[-1])
            target = target.view(-1, 1)[:, 0]
            loss = F.nll_loss(pred, target, weight=weight)
        return loss

train_data = S3DISDataset(split='train', root=path, npoints=NUM_POINT, test_area=5, block_size=1.0, sample_rate=1.0, transform=None)
test_data = S3DISDataset(split='test', root=path, npoints=NUM_POINT, test_area=5, block_size=1.0, sample_rate=1.0, transform=None)
train_data.num_classes = 13
test_data.num_classes = 13
def get_model():
    return PointNetSeg(13)
# if __name__ == '__main__':
#     data_root = path
#     num_point, test_area, block_size, sample_rate = 4096, 5, 1.0, 0.01
#
#     point_data = S3DISDataset(split='train', data_root=data_root, num_point=num_point, test_area=test_area, block_size=block_size, sample_rate=sample_rate, transform=None)
#     print('point data size:', point_data.__len__())
#     print('point data 0 shape:', point_data.__getitem__(0)[0].shape)
#     print('point label 0 shape:', point_data.__getitem__(0)[1].shape)
#     import torch, time, random
#     manual_seed = 123
#     random.seed(manual_seed)
#     np.random.seed(manual_seed)
#     torch.manual_seed(manual_seed)
#     torch.cuda.manual_seed_all(manual_seed)
#     def worker_init_fn(worker_id):
#         random.seed(manual_seed + worker_id)
#     train_loader = torch.utils.data.DataLoader(point_data, batch_size=16, shuffle=True, num_workers=16, pin_memory=True, worker_init_fn=worker_init_fn)
#     for idx in range(4):
#         end = time.time()
#         for i, (input, target) in enumerate(train_loader):
#             print('time: {}/{}--{}'.format(i+1, len(train_loader), time.time() - end))
#             end = time.time()