import torchvision
import os
import torchvision.transforms as T
import torch
import flgo.benchmark
CLASSES = (
        '__background__',
        "aeroplane",
        "bicycle",
        "bird",
        "boat",
        "bottle",
        "bus",
        "car",
        "cat",
        "chair",
        "cow",
        "diningtable",
        "dog",
        "horse",
        "motorbike",
        "person",
        "pottedplant",
        "sheep",
        "sofa",
        "train",
        "tvmonitor",
    )
CLASSES_MAP = {name:idx for idx, name in enumerate(CLASSES)}

transform = T.Compose([T.ToTensor(), T.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])

target_transform = T.Compose([
    T.PILToTensor(),
    T.Lambda(lambda x: x.squeeze().type(torch.LongTensor)),
])

path = os.path.join(flgo.benchmark.path, 'RAW_DATA', 'PASCAL_VOC')
train_data = torchvision.datasets.VOCSegmentation(path, download=True, image_set='trainval', year='2007', transform=transform, target_transform=target_transform)
test_data = torchvision.datasets.VOCSegmentation(path, download=True, image_set='test', year='2007', transform=transform, target_transform=target_transform)
train_data.num_classes = len(CLASSES)
test_data.num_classes = len(CLASSES)

def get_model():
    model = torchvision.models.segmentation.fcn_resnet50(num_classes=len(CLASSES))
    return model
