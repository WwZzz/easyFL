import torch.utils.data
import torch.nn as nn
import json
import numpy as np
import os
import torch
import torch.nn as nn
import torch.utils.data
from torch.autograd import Variable
import flgo.utils.fmodule
import numpy as np
import torch.nn.functional as F
from flgo.benchmark.toolkits.cv.point_cloud_classification.pointnet_utils import feature_transform_reguliarzer, STNkd, STN3d, PointNetEncoder
from torchvision.datasets.utils import download_and_extract_archive, extract_archive
path = os.path.join(os.path.dirname(__file__), 'shapenetcore_partanno_segmentation_benchmark_v0')

class ShapeNetDataset(torch.utils.data.Dataset):
    url = "https://shapenet.cs.stanford.edu/ericyi/shapenetcore_partanno_segmentation_benchmark_v0.zip"
    def __init__(self,
                 root,
                 npoints=2500,
                 split='train',
                 data_augmentation=True):
        self.npoints = npoints
        self.root = root
        self.catfile = os.path.join(self.root, 'synsetoffset2category.txt')
        if not os.path.exists(self.root):
            zipfile = os.path.join(os.path.dirname(self.root), 'shapenetcore_partanno_segmentation_benchmark_v0.zip')
            if os.path.exists(zipfile):
                extract_archive(zipfile, os.path.dirname(self.root), remove_finished=True)
            else:
                download_and_extract_archive(self.url, download_root=os.path.dirname(self.root),remove_finished=True)

        self.cat = {}
        self.data_augmentation = data_augmentation
        self.classification = True
        self.seg_classes = {}

        with open(self.catfile, 'r') as f:
            for line in f:
                ls = line.strip().split()
                self.cat[ls[0]] = ls[1]
        # print(self.cat)
        self.id2cat = {v: k for k, v in self.cat.items()}

        self.meta = {}
        splitfile = os.path.join(self.root, 'train_test_split', 'shuffled_{}_file_list.json'.format(split))
        # from IPython import embed; embed()
        filelist = json.load(open(splitfile, 'r'))
        for item in self.cat:
            self.meta[item] = []

        for file in filelist:
            _, category, uuid = file.split('/')
            if category in self.cat.values():
                self.meta[self.id2cat[category]].append((os.path.join(self.root, category, 'points', uuid + '.pts'),
                                                         os.path.join(self.root, category, 'points_label',
                                                                      uuid + '.seg')))

        self.datapath = []
        for item in self.cat:
            for fn in self.meta[item]:
                self.datapath.append((item, fn[0], fn[1]))

        self.classes = dict(zip(sorted(self.cat), range(len(self.cat))))
        print(self.classes)
        self.seg_classes = {'Airplane': 4, 'Bag':2, 'Cap':2, 'Car':4, 'Chair':4, 'Earphone':3, 'Guitar':3, 'Knife':2, 'Lamp':4, 'Laptop':2, 'Motorbike':6, 'Mug':2, 'Pistol':3, 'Rocket':3, 'Skateboard':3, 'Table':3}
        self.num_seg_classes = self.seg_classes[list(self.cat.keys())[0]]
        print(self.seg_classes, self.num_seg_classes)

    def __getitem__(self, index):
        fn = self.datapath[index]
        cls = self.classes[self.datapath[index][0]]
        point_set = np.loadtxt(fn[1]).astype(np.float32)
        seg = np.loadtxt(fn[2]).astype(np.int64)
        # print(point_set.shape, seg.shape)

        choice = np.random.choice(len(seg), self.npoints, replace=True)
        # resample
        point_set = point_set[choice, :]

        point_set = point_set - np.expand_dims(np.mean(point_set, axis=0), 0)  # center
        dist = np.max(np.sqrt(np.sum(point_set ** 2, axis=1)), 0)
        point_set = point_set / dist  # scale

        if self.data_augmentation:
            theta = np.random.uniform(0, np.pi * 2)
            rotation_matrix = np.array([[np.cos(theta), -np.sin(theta)], [np.sin(theta), np.cos(theta)]])
            point_set[:, [0, 2]] = point_set[:, [0, 2]].dot(rotation_matrix)  # random rotation
            point_set += np.random.normal(0, 0.02, size=point_set.shape)  # random jitter

        seg = seg[choice]
        point_set = torch.from_numpy(point_set)
        seg = torch.from_numpy(seg)
        cls = torch.from_numpy(np.array([cls]).astype(np.int64))

        if self.classification:
            return point_set, cls
        else:
            return point_set, seg

    def __len__(self):
        return len(self.datapath)

train_data = ShapeNetDataset(path, split='train', data_augmentation=True)
val_data = ShapeNetDataset(path, split='val', data_augmentation=True)
test_data = ShapeNetDataset(path, split='test', data_augmentation=False)

class PointNetCls(flgo.utils.fmodule.FModule):
    def __init__(self, k=2, feature_transform=False):
        super(PointNetCls, self).__init__()
        self.feature_transform = feature_transform
        self.feat = PointNetEncoder(global_feat=True, feature_transform=feature_transform)
        self.fc1 = nn.Linear(1024, 512)
        self.fc2 = nn.Linear(512, 256)
        self.fc3 = nn.Linear(256, k)
        self.dropout = nn.Dropout(p=0.3)
        self.bn1 = nn.BatchNorm1d(512)
        self.bn2 = nn.BatchNorm1d(256)
        self.relu = nn.ReLU()

    def forward(self, x):
        x, trans, trans_feat = self.feat(x)
        x = F.relu(self.bn1(self.fc1(x)))
        x = F.relu(self.bn2(self.dropout(self.fc2(x))))
        x = self.fc3(x)
        if self.training:
            return F.log_softmax(x, dim=1), trans, trans_feat
        else:
            return F.log_softmax(x, dim=1)

    def compute_loss(self, model_outputs, y):
        if self.training:
            ypred, trans, trans_feat = model_outputs
            loss = F.nll_loss(ypred, y)
            if trans_feat is not None:
                loss += 0.001 * feature_transform_reguliarzer(trans_feat)
            return loss
        else:
            return F.nll_loss(model_outputs, y)

def get_model():
    return PointNetCls(k=len(train_data.classes), feature_transform=True)